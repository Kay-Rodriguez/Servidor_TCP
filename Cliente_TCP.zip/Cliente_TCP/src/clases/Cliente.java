package clases;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class Cliente {
    public void enviar(String empleado) throws Exception {
        Socket socket = new Socket("172.31.116.73", 2025);

        InputStream in = socket.getInputStream();
        OutputStream out = socket.getOutputStream();

        // Enviar datos
        DataOutputStream dos = new DataOutputStream(out);
        dos.writeUTF("Alessia Pérez");

        // Recibir datos
        DataInputStream dis = new DataInputStream(in);
        String fecha = dis.readUTF();

        System.out.println("Hora de registro del empleado: " + empleado+ ",fecha: "+fecha);

        socket.close();
    }
}