package test;

import clases.Cliente;

import java.util.Scanner;

public class testCliente {
    static void main(String[] args) throws Exception{

        //El cliente va a enviar el nombre String de la persona
        //Enviar String nombre = "Juan Pérez";

        String nombre = "";
        System.out.println("APP REGISTRO");
        System.out.print("Ingrese su nombre: ");
        Scanner scanner =new Scanner(System.in);
        nombre = scanner.nextLine();

        Cliente cliente = new Cliente();
        cliente.enviar(nombre);
    }
}
